package EldarRiskovich;

public class PremiumAccount extends StandardAccount {

    public PremiumAccount(int accountNumber) {
        super(accountNumber, Double.NEGATIVE_INFINITY);
    }
}