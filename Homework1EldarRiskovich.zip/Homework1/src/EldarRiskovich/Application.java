package EldarRiskovich;

public class Application {
    public static void Main(String[] args) {

    }
}
