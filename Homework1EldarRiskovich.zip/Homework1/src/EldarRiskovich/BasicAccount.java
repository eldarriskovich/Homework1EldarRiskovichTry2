package EldarRiskovich;

public class BasicAccount extends StandardAccount {

    protected double withdrawalLimit;

    public BasicAccount(int accountNumber, double withdrawalLimit) {
        super(accountNumber, 0);
        this.withdrawalLimit = withdrawalLimit;
    }

    @Override
    public double Withdraw(double amount) {
        double maximum = 0;
        if(amount > withdrawalLimit)
            maximum = withdrawalLimit;
        else
            maximum = amount;

        if(maximum > balance) {
            maximum = balance;
            balance = 0;
            return maximum;
        }
        else {
            balance = balance - maximum;
            return maximum;
        }
    }

}