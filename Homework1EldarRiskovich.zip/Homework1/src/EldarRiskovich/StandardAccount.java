package EldarRiskovich;

import EldarRiskovich.IAccount;

public class StandardAccount implements IAccount {

    protected int accountNumber;
    protected double creditLimit;
    protected double balance;
    public StandardAccount(int accountNumber, double creditLimit) {
        this.accountNumber = accountNumber;
        if(creditLimit > 0)
            this.creditLimit = 0;
        else
            this.creditLimit = creditLimit;
        balance = 0;
    }

    @Override
    public void Deposit(double amount) {
        this.balance += amount;
    }

    @Override
    public double Withdraw(double amount) {
        double maximum = balance - creditLimit;
        if(amount > maximum) {
            balance -= maximum;
            return maximum;
        }
        else {
            balance -= amount;
            return amount;
        }
    }

    @Override
    public double GetCurrentBalance() {
        return balance;
    }

    @Override
    public int GetAccountNumber() {
        return accountNumber;
    }
}